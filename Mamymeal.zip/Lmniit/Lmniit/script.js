document.addEventListener("DOMContentLoaded", function () {
    // Map Initialization
    const map = L.map("map").setView([20.5937, 78.9629], 5); // Default: India coordinates

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    }).addTo(map);

    // Predefined locations with their coordinates
    const cityCoordinates = {
        "Delhi": [28.6139, 77.2090],
        "Mumbai": [19.0760, 72.8777],
        "Kolkata": [22.5726, 88.3639],
        "Chennai": [13.0827, 80.2707],
        // Add more cities as needed...
    };

    // Array to hold registered NGOs
    const ngos = [];

    // NGO Registration Form Handling
    const ngoForm = document.getElementById("ngoForm");
    ngoForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const ngoName = document.getElementById("ngoName").value;
        const ngoAddress = document.getElementById("ngoAddress").value.trim();
        const ngoContact = document.getElementById("ngoContact").value;
        const ngoDescription = document.getElementById("ngoDescription").value;

        if (!ngoName || !ngoAddress || !ngoContact || !ngoDescription) {
            alert("Please fill all fields.");
            return;
        }

        const coordinates = cityCoordinates[ngoAddress];
        if (coordinates) {
            const newNgo = {
                name: ngoName,
                address: ngoAddress,
                contact: ngoContact,
                description: ngoDescription,
                location: coordinates,
            };
            ngos.push(newNgo);

            // Add a marker to the map
            L.marker(coordinates)
                .addTo(map)
                .bindPopup(`<b>${ngoName}</b><br>${ngoDescription}<br><i>Contact: ${ngoContact}</i>`)
                .openPopup();

            alert("NGO Registered and added to the map!");
            ngoForm.reset();
        } else {
            alert("Address not found in the predefined list. Please select a valid city.");
        }
    });

    // OTP Form Handling
    const otpForm = document.getElementById("otpForm");
    const mobileNumberInput = document.getElementById("mobileNumber");
    const sendOtpButton = document.getElementById("sendOtpButton");
    const otpField = document.getElementById("otpField");
    const otpInput = document.getElementById("otpInput");
    const verifyOtpButton = document.getElementById("verifyOtpButton");
    const donationFormSection = document.getElementById("donationFormSection");

    otpForm.addEventListener("submit", function (event) {
        event.preventDefault();
        const mobileNumber = mobileNumberInput.value;

        if (mobileNumber) {
            // Simulate sending OTP
            alert(`OTP sent to your mobile number: ${mobileNumber}`);
            sendOtpButton.disabled = true;
            otpField.style.display = "block";
        }
    });

    verifyOtpButton.addEventListener("click", function () {
        const otp = otpInput.value;

        if (otp === "1234") {
            alert("OTP verified successfully!");
            otpField.style.display = "none";
            donationFormSection.style.display = "block";
        } else {
            alert("Invalid OTP. Please try again.");
        }
    });

    // Donor Form Submission Handling
    const donorForm = document.getElementById("donorForm");

    donorForm.addEventListener("submit", async function (event) {
        event.preventDefault();

        const donorData = {
            name: document.getElementById("name").value,
            email: document.getElementById("email").value,
            address: document.getElementById("address").value,
            foodDetails: document.getElementById("foodDetails").value,
            foodType: document.getElementById("foodType").value,
            foodQuantity: document.getElementById("foodQuantity").value,
            availabilityDate: document.getElementById("availabilityDate").value
        };

        try {
            const response = await fetch('http://localhost:5000/register-donor', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(donorData)
            });

            const result = await response.json();
            if (response.ok) {
                alert(result.message);  // Success message
            } else {
                alert(`Error: ${result.message || 'An error occurred.'}`);
            }

            donorForm.reset();
        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred while registering the donor.');
        }
    });
});
