# app.py
from flask import Flask, request, jsonify

app = Flask(__name__)

# Route to handle Donor Registration
@app.route('/register-donor', methods=['POST'])
def register_donor():
    # Get data from the frontend (sent in the request body)
    data = request.get_json()
    name = data.get('name')
    email = data.get('email')

    # Process the data (e.g., save it to a database)
    print(f"Received donor: {name}, {email}")

    # Send back a response (success message)
    return jsonify({"message": "Donor registered successfully!"})

if __name__ == '__main__':
    app.run(debug=True)
